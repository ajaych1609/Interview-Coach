let recorder;
let stream;
let socket;
let isRecording = false;

const DEEPGRAM_API_KEY = "306b740cc1dde5986a53a337a42555db835df26f";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "start") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        startCapture(tabs[0].id);
        sendResponse({ status: "started" });
      }
    });
    return true;
  } else if (message.action === "stop") {
    stopCapture();
    sendResponse({ status: "stopped" });
    return true;
  } else if (message.action === "status") {
    sendResponse({ isRecording });
    return true;
  }
});

function startCapture(tabId) {
  chrome.tabCapture.capture({ audio: true, video: false }, (capturedStream) => {
    if (!capturedStream) { console.error('Failed to capture tab audio.'); return; }
    stream = capturedStream;
    isRecording = true;
    socket = new WebSocket('wss://api.deepgram.com/v1/listen?punctuate=true&language=en&model=nova-2', ['token', DEEPGRAM_API_KEY]);
    socket.onopen = () => {
      recorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      recorder.ondataavailable = async (event) => {
        if (event.data.size > 0 && socket.readyState === WebSocket.OPEN) { socket.send(event.data); }
      };
      recorder.start(250);
    };
    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const transcript = data.channel?.alternatives?.[0]?.transcript || '';
        const isFinal = data.is_final;
        if (transcript && isFinal) { broadcastTranscriptToTabs(transcript); }
      } catch (e) {}
    };
    socket.onerror = (err) => console.error('Socket error:', err);
    socket.onclose = () => stopCapture();
  });
}

function stopCapture() {
  if (recorder && recorder.state !== 'inactive') recorder.stop();
  if (stream) stream.getTracks().forEach((t) => t.stop());
  if (socket && socket.readyState === WebSocket.OPEN) socket.close();
  isRecording = false;
}

function broadcastTranscriptToTabs(text) {
  chrome.tabs.query({}, (tabs) => {
    for (const t of tabs) {
      chrome.tabs.sendMessage(t.id, { type: 'INTERVIEW_TRANSCRIPT', text }).catch(() => {});
    }
  });
}