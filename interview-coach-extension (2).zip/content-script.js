chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'INTERVIEW_TRANSCRIPT') {
    window.postMessage({ source: 'interview-deepgram-extension', type: 'INTERVIEW_TRANSCRIPT', text: message.text }, '*');
  }
});