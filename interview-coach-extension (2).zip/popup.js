const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const status = document.getElementById('status');

function updateStatus() {
  chrome.runtime.sendMessage({ action: 'status' }, (response) => {
    if (response && response.isRecording) {
      status.textContent = 'Status: 🔴 Recording';
      status.style.backgroundColor = '#ffebee';
    } else {
      status.textContent = 'Status: Not Recording';
      status.style.backgroundColor = '#f0f0f0';
    }
  });
}

startBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'start' }, () => setTimeout(updateStatus, 500));
});

stopBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'stop' }, () => setTimeout(updateStatus, 500));
});

updateStatus();